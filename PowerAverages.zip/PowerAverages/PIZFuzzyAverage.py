import pandas as pd

def average_pid_fuzzy(file_path):
    # Read the CSV file
    df = pd.read_csv(file_path)

    # Convert Power, Current, and Voltage columns to numeric, coercing errors to NaN
    df[['Power (mW)', 'Current (mA)', 'Voltage (V)']] = df[['Power (mW)', 'Current (mA)', 'Voltage (V)']].apply(pd.to_numeric, errors='coerce')

    # Drop rows with any NaN values (e.g., from 'N/A' or empty cells)
    df_cleaned = df.dropna(subset=['Power (mW)', 'Current (mA)', 'Voltage (V)'])

    # Calculate averages
    averages = df_cleaned[['Power (mW)', 'Current (mA)', 'Voltage (V)']].mean()

    return averages

# Example usage:
pid_averages = average_pid_fuzzy("power_measurementsPIDPWM5min.csv")
fuzzy_averages = average_pid_fuzzy("power_measurementsFUZZYPWM12min.csv")

print("PID Averages:\n", pid_averages)
print("Fuzzy Averages:\n", fuzzy_averages)
