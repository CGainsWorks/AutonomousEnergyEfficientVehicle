import pandas as pd

def average_sleep_modes_with_power_calc(file_path):
    # Read the CSV file
    df = pd.read_csv(file_path)

    # Convert Power, Current, Voltage to numeric, coercing errors to NaN
    df[['Power (mW)', 'Current (mA)', 'Voltage (V)']] = df[['Power (mW)', 'Current (mA)', 'Voltage (V)']].apply(pd.to_numeric, errors='coerce')

    # Filter valid modes (POWER, LIGHT_SLEEP, DEEP_SLEEP), exclude RESTART and N/A rows
    valid_modes = ['POWER', 'LIGHT_SLEEP', 'DEEP_SLEEP']
    df_filtered = df[df['Mode'].isin(valid_modes)]

    # Drop rows with NaN in Power, Current, or Voltage columns
    df_filtered = df_filtered.dropna(subset=['Power (mW)', 'Current (mA)', 'Voltage (V)'])

    # Group by Mode and calculate averages
    averages_by_mode = df_filtered.groupby('Mode')[['Power (mW)', 'Current (mA)', 'Voltage (V)']].mean()

    # Calculate average power if it's zero or NaN (redundant but robust)
    for mode in averages_by_mode.index:
        power = averages_by_mode.loc[mode, 'Power (mW)']
        current = averages_by_mode.loc[mode, 'Current (mA)']
        voltage = averages_by_mode.loc[mode, 'Voltage (V)']

        if power == 0 or pd.isna(power):
            averages_by_mode.loc[mode, 'Power (mW)'] = current * voltage

    return averages_by_mode


# Example usage:
sleep_averages = average_sleep_modes_with_power_calc("power_measurements_sleepmodes.csv")
print("Sleep Mode Averages (with Power calculated if missing):\n", sleep_averages)
