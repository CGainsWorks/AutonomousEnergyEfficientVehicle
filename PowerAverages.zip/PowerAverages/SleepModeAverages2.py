import pandas as pd

def average_pid_fuzzy(file_path):
    """
    Averages Power, Current, Voltage for PID or Fuzzy measurements.
    """
    df = pd.read_csv(file_path)

    # Convert Power, Current, Voltage to numeric, coerce 'N/A' to NaN
    df[['Power (mW)', 'Current (mA)', 'Voltage (V)']] = df[['Power (mW)', 'Current (mA)', 'Voltage (V)']].apply(pd.to_numeric, errors='coerce')

    # Drop rows with NaNs
    df_cleaned = df.dropna(subset=['Power (mW)', 'Current (mA)', 'Voltage (V)'])

    # Calculate the averages
    averages = df_cleaned[['Power (mW)', 'Current (mA)', 'Voltage (V)']].mean()

    return averages


def average_sleep_modes(files):
    """
    Averages Power, Current, Voltage for each Sleep Mode (POWER, LIGHT_SLEEP, DEEP_SLEEP).
    If Power, Current, or Voltage is 0 or NaN for a mode, it estimates the missing value.
    """
    # Read and combine multiple sleep mode CSVs
    dfs = [pd.read_csv(file) for file in files]
    df = pd.concat(dfs, ignore_index=True)

    # Convert Power, Current, Voltage to numeric, coerce 'N/A' to NaN
    df[['Power (mW)', 'Current (mA)', 'Voltage (V)']] = df[['Power (mW)', 'Current (mA)', 'Voltage (V)']].apply(pd.to_numeric, errors='coerce')

    # Filter only valid modes
    valid_modes = ['POWER', 'LIGHT_SLEEP', 'DEEP_SLEEP']
    df_filtered = df[df['Mode'].isin(valid_modes)]

    # Drop rows where ALL power, current, and voltage are NaN
    df_filtered = df_filtered.dropna(subset=['Power (mW)', 'Current (mA)', 'Voltage (V)'], how='all')

    # Fill missing values using the Power = Voltage * Current relationship
    for index, row in df_filtered.iterrows():
        power = row['Power (mW)']
        current = row['Current (mA)']
        voltage = row['Voltage (V)']

        if pd.isna(power) or power == 0:
            if pd.notna(voltage) and pd.notna(current):
                df_filtered.at[index, 'Power (mW)'] = voltage * current

        if pd.isna(current) or current == 0:
            if pd.notna(power) and pd.notna(voltage) and voltage != 0:
                df_filtered.at[index, 'Current (mA)'] = power / voltage

        if pd.isna(voltage) or voltage == 0:
            if pd.notna(power) and pd.notna(current) and current != 0:
                df_filtered.at[index, 'Voltage (V)'] = power / current

    # Group by Mode and calculate averages
    averages_by_mode = df_filtered.groupby('Mode')[['Power (mW)', 'Current (mA)', 'Voltage (V)']].mean()

    return averages_by_mode


# Example Usage:
pid_averages = average_pid_fuzzy("power_measurementsPIDPWM5min.csv")
fuzzy_averages = average_pid_fuzzy("power_measurementsFUZZYPWM12min.csv")

sleep_averages = average_sleep_modes(["power_measurements_sleepmodes.csv", "power_measurements_sleepmodes2.csv"])

print("PID Averages:\n", pid_averages)
print("Fuzzy Averages:\n", fuzzy_averages)
print("Sleep Mode Averages:\n", sleep_averages)
