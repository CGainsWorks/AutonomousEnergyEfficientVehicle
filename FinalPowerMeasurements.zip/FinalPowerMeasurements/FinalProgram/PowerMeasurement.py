import socket
import csv
import time

HOST = '0.0.0.0'  # Listen on all available interfaces
PORT = 5000

def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((HOST, PORT))
        server_socket.listen()
        print(f"Server listening on {HOST}:{PORT}")

        with open("power_measurements.csv", "a", newline="") as csvfile:
            csv_writer = csv.writer(csvfile)
            csv_writer.writerow(["Timestamp", "Power (mW)", "Current (mA)", "Voltage (V)"])

            while True:
                conn, addr = server_socket.accept()
                print(f"Connected by {addr}")
                with conn:
                    while True:
                        data = conn.recv(1024)
                        if not data:
                            break
                        try:
                            decoded_data = data.decode().strip()
                            power, current, voltage = map(float, decoded_data.split(","))
                            timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                            csv_writer.writerow([timestamp, power, current, voltage])
                            csvfile.flush()
                            print(f"{timestamp} | Power: {power} mW | Current: {current} mA | Voltage: {voltage} V")
                        except Exception as e:
                            print(f"Error processing data: {e}")

if __name__ == "__main__":
    main()
