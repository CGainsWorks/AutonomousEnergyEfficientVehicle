import socket
import csv
import time

HOST = '0.0.0.0'
PORT = 5000


def main():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.settimeout(1.0)  # Periodically check for exit condition
        server_socket.bind((HOST, PORT))
        server_socket.listen()
        print(f"Server listening on {HOST}:{PORT}")

        with open("power_measurements.csv", "a", newline="") as csvfile:
            csv_writer = csv.writer(csvfile)

            # Optional: Check if the file is empty before writing headers
            if csvfile.tell() == 0:
                csv_writer.writerow(["Timestamp", "Power (mW)", "Current (mA)", "Voltage (V)"])

            try:
                while True:
                    try:
                        conn, addr = server_socket.accept()
                        print(f"Connected by {addr}")
                        conn.settimeout(1.0)  # Avoid blocking indefinitely

                        with conn:
                            while True:
                                try:
                                    data = conn.recv(1024)
                                    if not data:
                                        print(f"Client {addr} disconnected.")
                                        break  # Client closed connection

                                    decoded_data = data.decode().strip()
                                    power, current, voltage = map(float, decoded_data.split(","))
                                    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                                    csv_writer.writerow([timestamp, power, current, voltage])
                                    csvfile.flush()
                                    print(f"{timestamp} | Power: {power} mW | Current: {current} mA | Voltage: {voltage} V")

                                except socket.timeout:
                                    # Timeout allows checking for interruptions, but doesn't close the connection
                                    continue

                                except ValueError as e:
                                    print(f"Invalid data from {addr}: {decoded_data}. Error: {e}")

                    except socket.timeout:
                        # No connection, continue listening
                        continue

                    except ConnectionResetError:
                        # Handle abrupt client disconnections
                        print(f"Client {addr} connection reset. Waiting for new connection...")

                    except OSError as e:
                        # Handle other socket errors like stopping the server
                        print(f"Socket error: {e}")
                        break

            except KeyboardInterrupt:
                print("Server shutting down gracefully...")


if __name__ == "__main__":
    main()
