import socket
import csv
import time
import threading

HOST = '0.0.0.0'
PORT_POWER = 5000
PORT_MODE = 5001

stop_event = threading.Event()
csv_lock = threading.Lock()

# Store the latest mode state to associate with power data
latest_mode = "UNKNOWN"

def handle_power_data():
    global latest_mode
    while not stop_event.is_set():
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
                server_socket.bind((HOST, PORT_POWER))
                server_socket.listen()
                print(f"Power Data Server listening on {HOST}:{PORT_POWER}")

                while not stop_event.is_set():
                    server_socket.settimeout(1.0)
                    try:
                        conn, _ = server_socket.accept()
                    except socket.timeout:
                        continue

                    with conn:
                        print("Power Data Client Connected")
                        while not stop_event.is_set():
                            try:
                                data = conn.recv(1024).decode().strip()
                                if not data:
                                    print("Power Data Client Disconnected")
                                    break

                                timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                                try:
                                    power, current, voltage = map(float, data.split(","))
                                    with csv_lock, open("power_measurements.csv", "a", newline="") as f:
                                        csv.writer(f).writerow(
                                            [timestamp, f"{power:.4f}", f"{current:.4f}", f"{voltage:.4f}", latest_mode]
                                        )
                                    print(f"{timestamp} | Power: {power:.4f} mW | Current: {current:.4f} mA | Voltage: {voltage:.4f} V | Mode: {latest_mode}")

                                except ValueError:
                                    print(f"{timestamp} | Invalid Power Data: {data}")
                            except ConnectionResetError:
                                print("Power Data Client forcibly closed connection")
                                break

        except OSError as e:
            print(f"Power Data Server Error: {e}")
            time.sleep(2)  # Prevent rapid retries if port is busy


def handle_mode_data():
    global latest_mode
    while not stop_event.is_set():
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
                server_socket.bind((HOST, PORT_MODE))
                server_socket.listen()
                print(f"Mode Data Server listening on {HOST}:{PORT_MODE}")

                while not stop_event.is_set():
                    server_socket.settimeout(1.0)
                    try:
                        conn, _ = server_socket.accept()
                    except socket.timeout:
                        continue

                    with conn:
                        print("Mode Data Client Connected")
                        while not stop_event.is_set():
                            try:
                                data = conn.recv(1024).decode().strip()
                                if not data:
                                    print("Mode Data Client Disconnected")
                                    break

                                timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
                                latest_mode = data  # Update the global latest_mode state
                                with csv_lock, open("power_measurements.csv", "a", newline="") as f:
                                    csv.writer(f).writerow([timestamp, "N/A", "N/A", "N/A", data])

                                print(f"{timestamp} | Mode Update: {data}")

                            except ConnectionResetError:
                                print("Mode Data Client forcibly closed connection")
                                break

        except OSError as e:
            print(f"Mode Data Server Error: {e}")
            time.sleep(2)


def main():
    try:
        t1 = threading.Thread(target=handle_power_data, daemon=True)
        t2 = threading.Thread(target=handle_mode_data, daemon=True)

        t1.start()
        t2.start()

        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print("Stopping gracefully...")
        stop_event.set()


if __name__ == "__main__":
    # Only write the header if file doesn't exist
    try:
        with open("power_measurements.csv", "x", newline="") as f:
            csv.writer(f).writerow(["Timestamp", "Power (mW)", "Current (mA)", "Voltage (V)", "Mode"])
    except FileExistsError:
        pass  # Skip writing header if file already exists

    main()
